extends CharacterBody2D

const TILESIZE= 32.0
const speed =1
var currentdir:="down"
#var player=preload("res://Classes/PlayerClass.gd")
@onready var anim = $AnimatedSprite2D

func _physics_process(x: float):
	PlayerMovement(x)

func PlayerMovement(x):
	if Input.is_action_pressed("ui_left"):# and !$right.is_colliding():
		velocity.x= -TILESIZE
		velocity.y=0
		move_and_slide()
		currentdir="left"
		PlayAnim(1)
	elif Input.is_action_pressed("ui_right"):# and !$left.is_colliding():
		velocity.x= TILESIZE
		velocity.y=0
		move_and_slide()
		currentdir="right"
		PlayAnim(1)
	elif Input.is_action_pressed("ui_up"):# and !$up.is_colliding():
		velocity.x=0
		velocity.y= -TILESIZE
		move_and_slide()
		currentdir="up"
		PlayAnim(1)
	elif Input.is_action_pressed("ui_down"):# and !$down.is_colliding():
		velocity.x=0
		velocity.y= TILESIZE
		move_and_slide()
		currentdir="down"
		PlayAnim(1)
	else :
		velocity.x=0
		velocity.y=0
		PlayAnim(0)

func PlayAnim(movement: int):
	var dir:=currentdir
	#if movement==1:player.TurnIncrement()
	if dir=="left":
		anim.flip_h=true
		if movement==1:anim.play("sidewalk")
		else: anim.play("sideidle")
	elif dir=="right":
		anim.flip_h=false
		if movement==1:anim.play("sidewalk")
		else: anim.play("sideidle")
	elif dir=="up":
		if movement==1:anim.play("upwalk")
		else: anim.play("upidle")
	elif dir=="down":
		if movement==1:anim.play("downwalk")
		else: anim.play("downidle")
	else: anim.play("downidle")

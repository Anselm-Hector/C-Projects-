extends Node

#add range to equip class

var timer:=0

func inrange():
	if player.range<=dis:
		attack.visible=true

func OnAttackPressed():
	timer= weapon.attspeed-1
	if timer>0:turnincrement()
	if Weapon("").enchant==true:
		var enchantproc=randi() % 3 + 20
		if enchantproc==range(0,3):EnchantEff()
	var x=player.minval+player.damage 
	var y=player.maxval+player.damage
	var damage=randi()%x+y
	var dmgres=randi() % enemy.minval + enemy.maxval
	var dmgdealt=dmgres-damage
	if enemy.sheild==true:
		var remainingsheild=enemy.sheildval-dmgdealt
		enemy.sheildval-=dmgdealt
		if remainingsheild<0:
			enemy.sheildval=0
			enemy.health+=remainingsheild
		else: enemy.health-=dmgdealt
	

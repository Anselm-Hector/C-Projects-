extends Node
class_name Player

var hunger:=maxhunger
var turn:=0
var tick:=0
var level:=0
var expreq:=20
var expcurr:=0
var character:=""
var health:=0
var maxhunger:=0
var damage:=0
var attspeed:=0
var knockbackres:=0

const CLASS= {
	"Warrior":{"a":30,"b":400,"c":3,"d":1.1,"e":2},
	"Alchemist":{"a":20,"b":300,"c":1,"d":1,"e":0}
	}

func Class(classname: String):
	var data=classname
	character=classname
	health=data.a
	maxhunger=data.b
	damage=data.c
	attspeed=data.d
	knockbackres=data.e

func TurnIncrement():
	turn+=1
	HungerCheck()

func LevelUp():
	if expcurr==expreq:
		level+=1
		expcurr=0
		expreq+=5

func HungerCheck():
	hunger-=1
	tick+=1
	if hunger>maxhunger/2.0:Healthy()
	elif hunger>0:Hungry()
	else: Starving()

func Healthy():
	if tick==20:
		health+=1
		tick=0

func Hungry():
	if tick==30:
		health+=1
		tick=0

func Starving():
	if tick==20:
		turn=0
		health-=1
		tick=0

const WARRIORDESC:="This guy is bulky, 
carries everything and hits like a golemn on steriods.
Keeps breaking the mages's expensive sticks"

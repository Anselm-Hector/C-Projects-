extends Node
class_name Item

var itemname:=""
var dice:=0
var dmg:=0
var dmgres:=0
var attspeed:=0
var knockback:=0
var knockbackres:=0
var currstack:=0
var maxstack:=0
var weapon:=false
var armour:=false
var stackable:=false
var potion:=false
var scroll:=false
var misc:=false
var enchant=false
var curse=false

func DealDmg():
	var dmgmod:=0
	match dice:
		1:dmgmod=4
		2:dmgmod=6
		3:dmgmod=8
	var damage=dmgmod+dmg

func TakeDmg():
	pass

extends Node

var Equipment = load("res://EquipmentClass.gd")

const WEAPON= {
	"Axe":{},
	"Sword":{},
	"Club":{},
	}

func Weapon(weapon: String):
	var data=WEAPON[weapon]
	
	Equipment.itemname=data.name
	Equipment.level=data.lvl
	Equipment.minval=data.min
	Equipment.maxval=data.max
	Equipment.mininc=data.mininc
	Equipment.maxinc=data.maxinc
	Equipment.attspeed=data.as
	Equipment.enchant=false
	Equipment.curse=false
	Equipment.weapon=true
#Equipment.AttSpeed=1.25

const ARMOUR= {
	"cloth":{},
	"leather":{},
	"mail":{}
	}

func Armour(armour: String):
	var data=ARMOUR[armour]
	pass

const MISC={
	"gold":{},
	"fangs":{},
	"spider legs":{}
	}

func Misc(misc: String):
	var data=MISC[misc]
	pass

const POTION={
	"sample":{}
	}

func Potion(potion: String):
	var data=POTION[potion]
	pass

const SCROLL={}

func Scroll(scroll: String):
	var data=SCROLL[scroll]
	pass

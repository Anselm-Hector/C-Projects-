extends Node
class_name Boss

var bossname:=""
var health:=0
var sheild :=0
var awake:=false
var damage:=0
var knockback:=0
var attspeed:=0

const BOSS= {
	"Spider Queen":{"a":150,"b":0,"c":8}
	}

func Boss(boss: String):
	var data=BOSS[boss]
	bossname=boss
	health=data.a
	sheild=data.b
	damage=data.c

extends Node
class_name Enemy

var enemyname:=""
var health:=0
var damage:=0
var expdrop:=0
var knockback:=0
var awake:=false
var loot:=false
var nest:=false
var elite:=false
var roamer:=false

const ENEMY={}

func Enemy(enemy: String):
	var data=ENEMY[enemy]
	pass

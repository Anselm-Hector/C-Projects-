extends Node2D
@onready var Desc=$CharacterSelect/Desc
@onready var MainMenu=$MainMenu
@onready var CharacterSelect=$CharacterSelect
@onready var Play=$CharacterSelect/Play
var player=load("res://Classes/PlayerClass.gd")
var p=player.new()
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	MainMenu.visible=true
	CharacterSelect.visible=false
	
func OnPlayPressed() -> void:
	MainMenu.visible=false
	CharacterSelect.visible=true
	Play.visible=false
	Desc.visible=false

func OnSettingsPressed() -> void:
	pass # Replace with function body.

func OnExitPressed() -> void:get_tree().quit()

func OnWarriorPressed() -> void:
	Play.visible=true
	Desc.visible=true
	Desc.text=player.WARRIORDESC

func OnAlchemistPressed() -> void:
	Play.visible=true
	Desc.visible=true
	Desc.text=player.ALCHEMISTDESC

func OnBackPressed() -> void:
	MainMenu.visible=true
	CharacterSelect.visible=false

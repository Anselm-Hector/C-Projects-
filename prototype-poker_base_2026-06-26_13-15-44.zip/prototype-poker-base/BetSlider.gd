extends VSlider

@onready var Buttons = get_node("res://Buttons.gd")
@onready var main = get_node("res://main.gd")
@onready var BetSlider = get_node("res://BetSlider.gd")
#@onready var BetSlider: Slider = $uix/HBoxContainer/Bet/BetSlider

func open_Slider():
	BetSlider.visible = true

func _ready() -> void:
	# Hard-code the minimum and maximum values
	BetSlider.value_changed.connect(_on_slider_value_changed)
	min_value = main.BigBlind
	max_value = main.playerchips

func _on_slider_value_changed(BetValue: int) -> void:
	print("The slider is now at: ", BetValue)

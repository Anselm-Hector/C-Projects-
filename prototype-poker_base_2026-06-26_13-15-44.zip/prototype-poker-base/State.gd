extends Node

@onready var main = get_node("res://main.gd")
@onready var Deck = get_node("res://Deck.gd")
@onready var Popups = $uix/Popups

func start_round():
	main.player_hand = [Deck.deal_card(), Deck.deal_card()]
	main.ai_hand = [Deck.deal_card(), Deck.deal_card()]
	Deck.show_player_cards()
	Popups.text = "Pre-Flop: Your move"

func deal_flop():
	for i in range(3):
		main.community_cards.append(Deck.deal_card())
	update_community_ui()
	Popups.text = "Flop"

func deal_turn():
	main.community_cards.append(Deck.deal_card())
	update_community_ui()
	Popups.text = "Turn"

func deal_river():
	main.community_cards.append(Deck.deal_card())
	update_community_ui()
	Popups.text = "River"

func update_community_ui():
	for card in main.community_cards:
		var label = Label.new()
		label.text = card.get_display_name()
		main.community_ui.add_child(label)


"res://Card_class.gd"

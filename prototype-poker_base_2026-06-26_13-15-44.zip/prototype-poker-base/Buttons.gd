extends Node

var bet_amount = 0
var AllIn = false

@onready var main = get_node("res://main.gd")
@onready var AiLogic = get_node("res://AiLogic.gd")
#@onready var BetSlider: Slider = $uix/HBoxContainer/Bet/BetSlider
@onready var BetSlider = get_node("res://BetSlider.gd")

func _on_ConfirmBet_pressed():
	bet_amount = BetSlider.BetValue
	BetSlider.visible = false

func _on_Bet_pressed():
	BetSlider.openslider()
	_on_ConfirmBet_pressed()
	main.player_chips -= bet_amount
	main.pot += bet_amount
	AiLogic.ai_action()

func _on_Call_pressed():
	bet_amount = 50
	main.player_chips -= bet_amount
	main.pot += bet_amount
	main.next_phase()

func _on_Fold_pressed():
	AllIn=true
	main.Popups.text = "You folded. AI wins!"
	
func _on_AllIn_pressed():
	main.player_chips -= main.player_chips
	main.pot += main.player_chips
	AiLogic.ai_action()

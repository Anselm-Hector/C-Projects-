extends Node2D
class_name Card

@export var suit:=""
@export var rank:=0
@export var inpile:=false

func _init(_suit: String, _rank: int):
	suit = _suit
	rank = _rank

func get_value():
	return rank

func get_display_name():
	var ranks = {
		11: "J", 12: "Q", 13: "K", 14: "A"
	}
	var display_rank = ranks.get(rank, str(rank))
	return display_rank + " of " + suit

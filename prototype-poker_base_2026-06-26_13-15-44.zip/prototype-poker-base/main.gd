extends Node2D

const STARTING_CHIPS = 1000
const BIGBLIND = 50
const SMALLBLIND = 25

var player_hand = []
var ai_hand = []
var community_cards = []

var player_chips = STARTING_CHIPS
var ai_chips = STARTING_CHIPS
var pot = 0
var phase = 0  # 0=preflop, 1=flop, 2=turn, 3=river, 4=showdown

@onready var Popups = $uix/Popups
@onready var player_cards_ui = $uix/PlayerCards
@onready var community_ui = $uix/CommunityCards
@onready var ai_cards_ui = $uix/AICards
@onready var State = get_node("res://State.gd")
@onready var Buttons = get_node("res://Buttons.gd")

func clear_board():
	player_cards_ui.queue_free_children()
	community_ui.queue_free_children()
	ai_cards_ui.queue_free_children()
	community_cards.clear()
	pot = 0

func show_player_cards():
	for card in player_hand:
		var label = Label.new()
		label.text = card.get_display_name()
		player_cards_ui.add_child(label)

func reveal_ai_cards():
	for card in ai_hand:
		var label = Label.new()
		label.text = card.get_display_name()
		ai_cards_ui.add_child(label)


func get_high_card(hand):
	var highest = 0
	for card in hand:
		highest = max(highest, card.get_value())
	return highest

func showdown():
	reveal_ai_cards()

	var player_score = get_high_card(player_hand + community_cards)
	var ai_score = get_high_card(ai_hand + community_cards)

	if player_score > ai_score:
		Popups.text = "You Win!"
		player_chips += pot
	elif ai_score > player_score:
		Popups.text = "AI Wins!"
		ai_chips += pot
	else:
		Popups.text = "Tie!"
		player_chips += pot / 2
		ai_chips += pot / 2

func next_phase():
	phase += 1
	if phase >= 7:
		return
	match phase:
		1:
			State.start_round()
		2:
			State.deal_flop()
		3:
			State.deal_turn()
		4:
			State.deal_river()
		5:
			showdown()
		6:
			clear_board()
			phase=0

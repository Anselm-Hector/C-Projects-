extends Node

@onready var main = get_node("res://main.gd")
@onready var Buttons = get_node("res://Buttons.gd")
@onready var Popups = $uix/Popups

func ai_action():
	# Very simple random AI
	if Buttons.AllIn==true:
		if randi() % 2 == 0:
			Popups.text = "AI Calls"
			main.ai_chips -= main.ai_chips
			main.pot += main.ai_chips
			main.phase=5
			main.next_phase()
			

	if randi() % 2 == 0:
		Popups.text = "AI Calls"
		main.ai_chips -= 50
		main.pot += 50
		main.next_phase()
	else:
		Popups.text = "AI Folds. You win!"
		main.player_chips += main.pot

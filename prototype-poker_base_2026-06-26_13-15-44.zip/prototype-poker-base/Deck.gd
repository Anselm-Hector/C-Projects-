extends Node
class_name Deck

const SUITS = ["Hearts", "Diamonds", "Clubs", "Spades"]
var cards= []

func create_deck():
	cards.clear()
	for suit in SUITS:
		for rank in range(2, 15):
			cards.append(Card.new(suit, rank))
	cards.shuffle()

func deal_card() -> Card:
	if cards.is_empty():
		return null
	return cards.pop_back()
	
